Sample configuration files for:

SystemD: lobstexd.service
Upstart: lobstexd.conf
OpenRC:  lobstexd.openrc
         lobstexd.openrcconf
CentOS:  lobstexd.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
