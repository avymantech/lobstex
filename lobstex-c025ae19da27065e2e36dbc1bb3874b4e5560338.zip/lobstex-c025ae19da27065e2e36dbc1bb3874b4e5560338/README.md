# lobstex

Welcome to the world of Privacy

Zerocoin Masternodes SwifTX


Website: www.lobstex.com

Introducing Lobstex (Ticker : LOBS) 

Official Launch Date : 02 May, 2018




COIN SPECS

Name: Lobstex 

Ticker: LOBS 

Algorithm: Quark 

Type: PoS and PoW (Initially)

RPC Port: 15156

P2P Port: 14146


MASTERNODES

Collateral: 10000 

LOBS Mature Time: 4 Hours


PREMINE

Total Premine Distribution: 1.5 mil (Locked)

WALLETS

www.lobstex.com 

https://github.com/avymantech/lobstex/releases/tag/v2.0

BLOCK EXPLORER

http://explorer.lobstex.com/

GITHUB

https://github.com/avymantech/lobstex

WHITEPAPER v1.0

http://lobstex.com/wp-content/uploads/2018/08/Lobstex-Whitepaper.pdf

BITCOINTALK ANN

https://bitcointalk.org/index.php?topic=3483089.0


EXCHANGES

Fatbtc

https://www.fatbtc.com/

CryptoBridge

https://crypto-bridge.org/ 

GRAVIEX 

https://graviex.net/markets/lobsbtc


CONTACT

support@lobstex.com 

vacancy@lobstex.com 

market@lobstex.com


SOCIAL

TWITTER https://twitter.com/LOBSTEXofficial 

DISCORD https://discord.gg/pdUX3Uh

TELEGRAM https://t.me/lobstexofficial 

REDDIT https://www.reddit.com/r/Lobstex/

FACEBOOK https://www.facebook.com/lobstex/

MEDIUM https://medium.com/lobstex
